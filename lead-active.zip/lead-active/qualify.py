"""Lead Active - sample lead scoring (rule-based demo)."""
import csv

SPAM_WORDS = ["free gift", "win money", "asdf", "lottery"]
INTENT_WORDS = ["interested", "book", "site visit", "price", "details", "call"]


def valid_phone(phone):
    return phone.isdigit() and len(phone) == 10 and phone[0] in "6789"


def score_lead(lead, seen_phones):
    msg = lead["message"].lower()

    # Fake checks first
    if not valid_phone(lead["phone"]):
        return 0, "Fake", "Invalid phone number"
    if lead["phone"] in seen_phones:
        return 0, "Fake", "Duplicate lead"
    if any(w in msg for w in SPAM_WORDS):
        return 5, "Junk", "Spam message"

    score = 0
    if lead["replied"] == "yes":
        score += 30
    if lead["budget"] == "Yes":
        score += 30
    if lead["timeline"] in ("This week", "This month"):
        score += 20
    elif lead["timeline"]:
        score += 10
    if any(w in msg for w in INTENT_WORDS):
        score += 20

    if score >= 70:
        return score, "Hot", "Strong buying intent"
    if score >= 40:
        return score, "Warm", "Some interest"
    return score, "Cold", "Low intent"


def main():
    seen = set()
    with open("sample_leads.csv", newline="") as f:
        for lead in csv.DictReader(f):
            score, label, reason = score_lead(lead, seen)
            seen.add(lead["phone"])
            print(f'{lead["id"]:>2} {lead["name"]:<12} {lead["source"]:<11} '
                  f'score={score:<3} {label:<5} ({reason})')


if __name__ == "__main__":
    main()
