# Lead Active

AI-powered lead quality filtering for sales teams. *(Concept + sample code, not a finished product.)*

## The problem
Ads on Meta, Google, WhatsApp and OTT platforms bring many leads, but a lot of them are fake, junk or not interested. Sales teams waste time calling them.

## The idea
Lead Active connects to ad platforms and the customer's messaging app (WhatsApp first). An AI talks to every new lead, finds out if they are really interested, and passes **only genuine leads** to the sales team.

## Flow
1. Lead comes from an ad (Meta / Google / WhatsApp / OTT)
2. Lead is sent to Lead Active
3. AI asks qualifying questions (budget, timeline, interest)
4. Lead is scored: **Hot, Warm, Cold, Junk or Fake**
5. Junk and fake leads are removed from the pipeline
6. Hot and warm leads go to a human sales agent
7. Dashboard shows lead quality per campaign

## What is in this repo
| File | Purpose |
|---|---|
| `qualify.py` | Sample scoring and classification logic |
| `sample_leads.csv` | Fake demo leads |
| `dashboard.html` | Visual preview of the analytics dashboard (open in browser) |

## Run the sample
```
python3 qualify.py
```
This reads `sample_leads.csv` and prints each lead with its score and label.

## Roadmap
- **Phase 1:** Lead analysis tool and dashboard
- **Phase 2:** Live WhatsApp AI conversations and handoff
- **Phase 3:** Send quality signals back to Meta and Google ads

## Planned tech
Python (FastAPI), PostgreSQL, WhatsApp Cloud API, Claude API for conversations.
